# File saved with Nlview 7.0.19  2019-03-26 bk=1.5019 VDI=41 GEI=35 GUI=JA:9.0 non-TLS-threadsafe
# 
# non-default properties - (restore without -noprops)
property attrcolor #000000
property attrfontsize 8
property autobundle 1
property backgroundcolor #ffffff
property boxcolor0 #000000
property boxcolor1 #000000
property boxcolor2 #000000
property boxinstcolor #000000
property boxpincolor #000000
property buscolor #008000
property closeenough 5
property createnetattrdsp 2048
property decorate 1
property elidetext 40
property fillcolor1 #ffffcc
property fillcolor2 #dfebf8
property fillcolor3 #f0f0f0
property gatecellname 2
property instattrmax 30
property instdrag 15
property instorder 1
property marksize 12
property maxfontsize 15
property maxzoom 6.25
property netcolor #19b400
property objecthighlight0 #ff00ff
property objecthighlight1 #ffff00
property objecthighlight2 #00ff00
property objecthighlight3 #ff6666
property objecthighlight4 #0000ff
property objecthighlight5 #ffc800
property objecthighlight7 #00ffff
property objecthighlight8 #ff00ff
property objecthighlight9 #ccccff
property objecthighlight10 #0ead00
property objecthighlight11 #cefc00
property objecthighlight12 #9e2dbe
property objecthighlight13 #ba6a29
property objecthighlight14 #fc0188
property objecthighlight15 #02f990
property objecthighlight16 #f1b0fb
property objecthighlight17 #fec004
property objecthighlight18 #149bff
property objecthighlight19 #eb591b
property overlapcolor #19b400
property pbuscolor #000000
property pbusnamecolor #000000
property pinattrmax 20
property pinorder 2
property pinpermute 0
property portcolor #000000
property portnamecolor #000000
property ripindexfontsize 8
property rippercolor #000000
property rubberbandcolor #000000
property rubberbandfontsize 15
property selectattr 0
property selectionappearance 2
property selectioncolor #0000ff
property sheetheight 44
property sheetwidth 68
property showmarks 1
property shownetname 0
property showpagenumbers 1
property showripindex 4
property timelimit 1
#
module new top work:top:NOFILE -nosplit
load symbol A2 work:A2:NOFILE HIERBOX pin A input.left pin B input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol N work:N:NOFILE HIERBOX pin A input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol N work:abstract:NOFILE HIERBOX pin A input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NA3O2 work:NA3O2:NOFILE HIERBOX pin A input.left pin B input.left pin C input.left pin D input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NAO2 work:NAO2:NOFILE HIERBOX pin A input.left pin B input.left pin C input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NAOA2 work:NAOA2:NOFILE HIERBOX pin A input.left pin B input.left pin C input.left pin D input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NEX2 work:NEX2:NOFILE HIERBOX pin A input.left pin B input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NO2 work:NO2:NOFILE HIERBOX pin A input.left pin B input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NO2 work:abstract:NOFILE HIERBOX pin A input.left pin B input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NO3 work:NO3:NOFILE HIERBOX pin A input.left pin B input.left pin C input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NO3 work:abstract:NOFILE HIERBOX pin A input.left pin B input.left pin C input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NOA3 work:NOA3:NOFILE HIERBOX pin A input.left pin B input.left pin C input.left pin D input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol NOA3 work:abstract:NOFILE HIERBOX pin A input.left pin B input.left pin C input.left pin D input.left pin Y output.right boxcolor 1 fillcolor 2 minwidth 13%
load port X1 input -pg 1 -lvl 0 -x 0 -y 420
load port X2 input -pg 1 -lvl 0 -x 0 -y 560
load port X3 input -pg 1 -lvl 0 -x 0 -y 620
load port X4 input -pg 1 -lvl 0 -x 0 -y 320
load port Y1 output -pg 1 -lvl 7 -x 1340 -y 280
load port Y2 output -pg 1 -lvl 7 -x 1340 -y 680
load port Y3 output -pg 1 -lvl 7 -x 1340 -y 740
load port Y4 output -pg 1 -lvl 7 -x 1340 -y 500
load inst A2_1 A2 work:A2:NOFILE -autohide -attr @cell(#000000) A2 -pg 1 -lvl 2 -x 240 -y 390
load inst N1 N work:N:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 1 -x 70 -y 370
load inst N2 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 3 -x 390 -y 510
load inst N3 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 3 -x 390 -y 610
load inst N4 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 5 -x 970 -y 200
load inst N5 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 4 -x 640 -y 70
load inst N6 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 4 -x 640 -y 300
load inst N7 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 4 -x 640 -y 670
load inst N8 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 5 -x 970 -y 290
load inst N9 N work:abstract:NOFILE -autohide -attr @cell(#000000) N -pg 1 -lvl 5 -x 970 -y 730
load inst NA3O2_1 NA3O2 work:NA3O2:NOFILE -autohide -attr @cell(#000000) NA3O2 -pg 1 -lvl 6 -x 1220 -y 470
load inst NAO2_1 NAO2 work:NAO2:NOFILE -autohide -attr @cell(#000000) NAO2 -pg 1 -lvl 6 -x 1220 -y 250
load inst NAOA2_1 NAOA2 work:NAOA2:NOFILE -autohide -attr @cell(#000000) NAOA2 -pg 1 -lvl 5 -x 970 -y 410
load inst NEX2_1 NEX2 work:NEX2:NOFILE -autohide -attr @cell(#000000) NEX2 -pg 1 -lvl 4 -x 640 -y 390
load inst NO2_1 NO2 work:NO2:NOFILE -autohide -attr @cell(#000000) NO2 -pg 1 -lvl 4 -x 640 -y 190
load inst NO2_2 NO2 work:abstract:NOFILE -autohide -attr @cell(#000000) NO2 -pg 1 -lvl 6 -x 1220 -y 670
load inst NO3_1 NO3 work:NO3:NOFILE -autohide -attr @cell(#000000) NO3 -pg 1 -lvl 4 -x 640 -y 530
load inst NO3_2 NO3 work:abstract:NOFILE -autohide -attr @cell(#000000) NO3 -pg 1 -lvl 6 -x 1220 -y 790
load inst NOA3_1 NOA3 work:NOA3:NOFILE -autohide -attr @cell(#000000) NOA3 -pg 1 -lvl 5 -x 970 -y 50
load inst NOA3_2 NOA3 work:abstract:NOFILE -autohide -attr @cell(#000000) NOA3 -pg 1 -lvl 5 -x 970 -y 570
load net X1 -pin A2_1 B -pin N5 A -pin NAOA2_1 D -pin NO2_1 B -pin NO3_2 C -pin NOA3_2 B -port X1
netloc X1 1 0 6 NJ 420 190 340 NJ 340 590 720 880 840 NJ
load net X2 -pin NA3O2_1 C -pin NAOA2_1 A -pin NEX2_1 B -pin NO3_1 C -port X2
netloc X2 1 0 6 NJ 560 NJ 560 NJ 560 510 480 860 520 NJ
load net X3 -pin N3 A -pin N6 A -pin NEX2_1 A -pin NO2_2 A -pin NOA3_2 C -port X3
netloc X3 1 0 6 NJ 620 NJ 620 340 660 570 620 860 680 NJ
load net X4 -pin N1 A -pin NO2_1 A -pin NO3_1 B -pin NO3_2 B -pin NOA3_1 D -pin NOA3_2 D -port X4
netloc X4 1 0 6 20 320 NJ 320 NJ 320 530 740 820 820 NJ
load net Y1 -pin NAO2_1 Y -pin NAOA2_1 B -port Y1
netloc Y1 1 4 3 920 340 NJ 340 1320
load net Y2 -pin NO2_2 Y -port Y2
netloc Y2 1 6 1 NJ 680
load net Y3 -pin N4 A -pin NO3_2 Y -port Y3
netloc Y3 1 4 3 900 800 1090J 740 1320
load net Y4 -pin NA3O2_1 Y -port Y4
netloc Y4 1 6 1 NJ 500
load net a2_11 -pin A2_1 Y -pin N2 A
netloc a2_11 1 2 1 340 400n
load net n_1 -pin A2_1 A -pin N1 Y -pin NAOA2_1 C
netloc n_1 1 1 4 170 460 NJ 460 NJ 460 N
load net n_2 -pin N2 Y -pin N7 A -pin NAO2_1 C
netloc n_2 1 3 3 490 780 NJ 780 1170
load net n_3 -pin N3 Y -pin NO3_1 A
netloc n_3 1 3 1 550 540n
load net n_4 -pin N4 Y -pin NA3O2_1 B
netloc n_4 1 5 1 1150 210n
load net n_5 -pin N5 Y -pin NOA3_1 B
netloc n_5 1 4 1 N 80
load net n_6 -pin N6 Y -pin NAO2_1 B -pin NOA3_1 C
netloc n_6 1 4 2 760 360 1070
load net n_7 -pin N7 Y -pin N9 A
netloc n_7 1 4 1 840 680n
load net n_8 -pin N8 Y -pin NO3_2 A
netloc n_8 1 5 1 1110 300n
load net n_9 -pin N9 Y -pin NO2_2 B
netloc n_9 1 5 1 1070 700n
load net naoa2_11 -pin NA3O2_1 A -pin NAOA2_1 Y
netloc naoa2_11 1 5 1 1130 440n
load net nex2_11 -pin N8 A -pin NEX2_1 Y
netloc nex2_11 1 4 1 780 300n
load net no2_11 -pin NO2_1 Y -pin NOA3_2 A
netloc no2_11 1 4 1 800 200n
load net no3_11 -pin NO3_1 Y -pin NOA3_1 A
netloc no3_11 1 4 1 740 60n
load net noa3_11 -pin NAO2_1 A -pin NOA3_1 Y
netloc noa3_11 1 5 1 1170 80n
load net noa3_22 -pin NA3O2_1 D -pin NOA3_2 Y
netloc noa3_22 1 5 1 1150 540n
levelinfo -pg 1 0 70 240 390 640 970 1220 1340
pagesize -pg 1 -db -bbox -sgen -70 0 1410 880
show
zoom 0.603067
scrollpos -411 -17
#
# initialize ictrl to current module top work:top:NOFILE
ictrl init topinfo |
