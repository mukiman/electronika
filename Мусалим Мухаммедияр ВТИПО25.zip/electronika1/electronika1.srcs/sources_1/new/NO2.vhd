library ieee;
use ieee.std_logic_1164.all;
entity NO2 is
    port(
        A, B : in  std_logic;
        Y    : out std_logic
    );
end NO2;

architecture beh of NO2 is
begin
    Y <= not (A or B) after 3 ns;
end beh;