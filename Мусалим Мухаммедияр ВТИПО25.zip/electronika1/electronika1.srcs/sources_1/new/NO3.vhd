library ieee;
use ieee.std_logic_1164.all;

entity NO3 is
    port(
        A, B, C : in  std_logic;
        Y       : out std_logic
    );
end NO3;

architecture beh of NO3 is
begin
    Y <= not (A or B or C) after 4 ns;
end beh;