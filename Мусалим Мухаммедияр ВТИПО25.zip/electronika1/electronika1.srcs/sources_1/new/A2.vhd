library ieee;
use ieee.std_logic_1164.all;

entity A2 is
    port(
        A, B : in  std_logic;
        Y    : out std_logic
    );
end A2;

architecture beh of A2 is
begin
    Y <= (A and B) after 2 ns;
end beh;