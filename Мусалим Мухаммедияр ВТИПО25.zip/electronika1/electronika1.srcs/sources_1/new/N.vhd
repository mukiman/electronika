library ieee;
use ieee.std_logic_1164.all;

entity N is
    port(
        A : in  std_logic;
        Y : out std_logic
    );
end N;

architecture beh of N is
begin
    Y <= not A after 1 ns;
end beh;