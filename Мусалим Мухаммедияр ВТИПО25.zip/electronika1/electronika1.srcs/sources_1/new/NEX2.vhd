library ieee;
use ieee.std_logic_1164.all;

entity NEX2 is
    port(
        A, B : in  std_logic;
        Y    : out std_logic
    );
end NEX2;

architecture beh of NEX2 is
begin
    Y <= (A xor B) after 5 ns;
end beh;