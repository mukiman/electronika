library ieee;
use ieee.std_logic_1164.all;

entity top is
    port(
        X1, X2, X3, X4 : in  std_logic;
        Y1, Y2, Y3, Y4 : out std_logic
    );
end top;

architecture structural of top is
    
    signal n_1, n_2,n_3,n_4,n_5,n_6,n_7,n_8,n_9,a2_11,no3_11,no3_22,nex2_11,no2_11,no2_22,noa3_11,noa3_22,naoa2_11,nao2_11,na3o2_11  : STD_LOGIC;
    
        component N
        Port ( A : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component NO2
        Port ( A, B : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component NO3
        Port ( A, B, C : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component NEX2
        Port ( A, B : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component NAO2
        Port ( A, B, C : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component NOA3
        Port ( A, B, C, D : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component NA3O2
        Port ( A, B, C, D : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component A2
        Port ( A, B : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

    component NAOA2
        Port ( A, B, C, D : in STD_LOGIC;
               Y : out STD_LOGIC);
    end component;

begin
    
    N1: N port map(x4, n_1);
    N2: N port map(a2_11, n_2);
    N3: N port map(x3,n_3);
    N4: N port map(no3_22,n_4);
    N5: N port map(x1, n_5);
    N6: N port map(x3,n_6);
    N7: N port map(n_2, n_7);
    N8: N port map(nex2_11,n_8);
    N9: N port map(n_7, n_9);

    NO2_1: NO2 port map(x4,x1,no2_11);
    NO2_2: NO2 port map(x3,n_9,no2_22);
   
    NO3_1: NO3 port map(n_3, x4, x2, no3_11);
    NO3_2: NO3 port map(n_8,x4,x1,no3_22);
   
    NOA3_1: NOA3 port map(no3_11,n_5,n_6,x4,noa3_11);
    NOA3_2: NOA3 port map(no2_11,x1, x3,x4,noa3_22);
       
    NEX2_1: NEX2 port map(x3, x2, nex2_11);
    
    NAO2_1: NAO2 port map(noa3_11, n_6, n_2,nao2_11);
    
    NA3O2_1: NA3O2 port map(naoa2_11,n_4, x2, noa3_22, na3o2_11);

    A2_1: A2 port map(n_1, x1, a2_11);
    
    NAOA2_1: NAOA2 port map(x2, nao2_11, n_1, x1, naoa2_11);

   
    y1 <= nao2_11;
    y2 <= no2_22;
    y3 <= no3_22;
    y4 <= na3o2_11;

    

end structural; 