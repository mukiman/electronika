library ieee;
use ieee.std_logic_1164.all;

entity NOA3 is
    port(
        A, B, C, D : in  std_logic;
        Y          : out std_logic
    );
end NOA3;

architecture beh of NOA3 is
begin
    Y <= not (A or (B and C and D)) after 5 ns;
end beh;