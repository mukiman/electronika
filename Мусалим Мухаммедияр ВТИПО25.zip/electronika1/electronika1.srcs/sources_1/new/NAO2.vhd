library ieee;
use ieee.std_logic_1164.all;

entity NAO2 is
    port(
        A, B, C : in  std_logic;
        Y       : out std_logic
    );
end NAO2;

architecture beh of NAO2 is
begin
    Y <= not (A and (B or C)) after 3 ns;
end beh;