library ieee;
use ieee.std_logic_1164.all;

entity NA3O2 is
    port(
        A, B, C, D : in  std_logic;
        Y          : out std_logic
    );
end NA3O2;

architecture beh of NA3O2 is
begin
    Y <= not ((A and B) and (C or D)) after 4 ns;
end beh;