library ieee;
use ieee.std_logic_1164.all;

entity NAOA2 is
    port(
        A, B, C, D : in  std_logic;
        Y          : out std_logic
    );
end NAOA2;

architecture beh of NAOA2 is
begin
    Y <= not (A and (B or (C and D))) after 4 ns;
end beh;